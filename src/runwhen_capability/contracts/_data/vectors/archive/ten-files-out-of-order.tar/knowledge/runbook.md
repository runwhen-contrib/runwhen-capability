restart it
